package br.edu.ifsp.bra;

public class Persistence {
    public void storeVideo() {
        System.out.println("Storing video...");
    }

    public void storeImage() {
        System.out.println("Storing image...");
    }
}
